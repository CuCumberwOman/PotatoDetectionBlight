def imread(path): 
    image = keras.utils.load_img(path) 
    image = tf.image.convert_image_dtype(image, tf.float32).numpy() 
    return image[..., :3] 

def resize(image, size=(128, 128)): 
    return transform.resize(image, size)

def read_neural():
    with open("model.json") as f: 
        model = keras.models.model_from_json(f.read()) 
    with open("model.pkl", "rb") as f: 
        model.set_weights(pickle.load(f)) 
    return model

def read_svm(path):
    with open(path, "rb") as f: 
        svm = pickle.load(f)
    return svm

def box_leaf(image, mask): 
    x = np.where(mask.max(axis=1)>0)[0] 
    y = np.where(mask.max(axis=0)>0)[0]
    return [image[x][:, y], mask[x][:, y]] 

def extract_leaves(neural, image): 
    x = np.array([resize(image)]) 
    pred = neural.predict(x, verbose=False)[0, ..., 0] 
    mask = pred > 0.75 
    labels, n = ndimage.label(mask) 
    s1, s2 = [], []
    for i in range(1, n+1):
        m = labels == i 
        m = resize(m, image.shape[:-1]) 
        img, mask = box_leaf(image, m)
        img[~mask] = 1
        s1.append(img)
        s2.append(mask)
    return s1, s2

def draw(values, model_name):
    result = np.zeros((len(values), 3))
    if model_name == "alternara":
        result[values == 0] = 0, 255, 0 
        result[values == 1] = 255, 255, 0 
        result[values == 2] = 255, 100, 0
        result[values == 3] = 15, 15, 15
    if model_name == "fitoftora":
        result[values == 0] = 0, 255, 0 
        result[values == 1] = 255, 255, 0 
        result[values == 2] = 255, 100, 0
        result[values == 3] = 150, 50, 0
        result[values == 4] = 255, 0, 0 
    return result

def svm_predict(svm, image, mask, model_name): 
    #image = ndimage.gaussian_filter(image, 4)
    data = image[mask > 0] 
    data = data.reshape((-1, 3)) 
    data = data * 255
    pred = svm.predict(data) 
    pic = np.zeros(image.shape) 
    pic[mask] = draw(pred, model_name) 
    pic[~mask] = 255 
    return pic, pred

def process_image(image, neural, svm, folder, name, split, model_name):
    if split: 
        leaves, masks = extract_leaves(neural, image)
    else:
        leaves, masks = [image], [np.ones(image.shape[:-1], dtype=bool)]
    stats = []
    if not os.path.exists(folder): 
        os.makedirs(folder)
    for i in range(len(leaves)):
        leaf = leaves[i]
        mask = masks[i]
        keras.utils.save_img(os.path.join(folder, f"{name}_{i}_clean.png"), leaf) 
        dis, pred = svm_predict(svm, leaf, mask, model_name) 
        keras.utils.save_img(os.path.join(folder, f"{name}_{i}_mask.png"), dis) 
        for j in np.unique(pred): 
            s = (pred==j).sum() 
            stats.append({"Картинка":name, 
                          "Болезнь":model_name, 
                          "Лист":i, 
                          "Степень болезни":j,
                          "Площадь листа":pred.size,
                          "Площадь болезни":s,
                          "Процент заражения": s/pred.size * 100
                         })
    pd.DataFrame(stats).to_csv(os.path.join(folder, f"{name}_stats.csv"))
        
def main(path_in="test.png", path_out="./temp", model="alternara", split_leaves=True):
    if os.path.isdir(path_in):
        images = [imread(os.path.join(path_in, x)) for x in os.listdir(path_in)]
        names = [os.path.basename(os.path.splitext(x)[0]) for x in os.listdir(path_in)] 
    else:
        images = [imread(path_in)]
        names = [os.path.basename(os.path.splitext(path_in)[0])]
    neural = read_neural()
    svm = read_svm(model)
    for i in range(len(images)):
        process_image(images[i], neural, svm, path_out, names[i], split_leaves, model)

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(
        prog='v1',
        description='Распознаватель заражения картофельных листов. Пример запуска: python main.py -i pics/test.png -o temp -m alternara',
        epilog="цвета/степени болезни на картинках:\n0 = зеленый\n1 = желтый\n2 = оранжевый,\n3 = коричневый (фитофтора), черный (альтернариоз)\n4 = красный (только фитофтора)")
    parser.add_argument('-i', '--input', default="./pics/test.png", help="входная картинка или папка")
    parser.add_argument('-o', '--output', default="./temp", help="папка для результата - картинок и таблица-сводки")
    parser.add_argument('-m', '--model', default="alternara", choices=["alternara", "fitoftora"], help="модель болезни")
    parser.add_argument('-L', '--no-leaves', action=argparse.BooleanOptionalAction, help="не разбивать листы")
    args = parser.parse_args()
    
    import os 
    import pickle
    import numpy as np
    import tensorflow.keras as keras
    import tensorflow as tf
    from skimage import transform
    from scipy import ndimage
    import pandas as pd
    main(args.input, args.output, args.model, not args.no_leaves)
